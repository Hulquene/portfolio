/* ============================================================
   HULQUENE ROBERTO NGOLA — PORTFOLIO
   script.js
   ============================================================ */

'use strict';

/* ── LOADER ─────────────────────────────────────────────────── */
(function initLoader() {
  const loader   = document.getElementById('loader');
  const bar      = document.getElementById('loader-bar');
  const pct      = document.getElementById('loader-pct');
  let  progress  = 0;

  const tick = setInterval(() => {
    progress += Math.random() * 18 + 4;
    if (progress >= 100) {
      progress = 100;
      clearInterval(tick);
      setTimeout(() => {
        loader.classList.add('hidden');
        document.body.style.overflow = '';
        animateHeroOnLoad();
      }, 300);
    }
    bar.style.width = progress + '%';
    pct.textContent = Math.floor(progress) + '%';
  }, 60);

  document.body.style.overflow = 'hidden';
})();

function animateHeroOnLoad() {
  // trigger GSAP-free stagger on hero elements already handled by CSS animations
}

/* ── CUSTOM CURSOR ──────────────────────────────────────────── */
(function initCursor() {
  const dot  = document.getElementById('cursor');
  const ring = document.getElementById('cursor-ring');
  if (!dot || !ring) return;

  let mx = window.innerWidth / 2, my = window.innerHeight / 2;
  let rx = mx, ry = my;
  let raf;

  document.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });

  function loop() {
    dot.style.left  = mx + 'px';
    dot.style.top   = my + 'px';
    rx += (mx - rx) * 0.1;
    ry += (my - ry) * 0.1;
    ring.style.left = rx + 'px';
    ring.style.top  = ry + 'px';
    raf = requestAnimationFrame(loop);
  }
  loop();

  document.querySelectorAll('a, button, .tag, .stack-cell, .proj-featured, .proj-small, .proj-wide').forEach(el => {
    el.addEventListener('mouseenter', () => { dot.classList.add('hovering'); ring.classList.add('hovering'); });
    el.addEventListener('mouseleave', () => { dot.classList.remove('hovering'); ring.classList.remove('hovering'); });
  });

  document.addEventListener('mouseleave', () => { dot.style.opacity = '0'; ring.style.opacity = '0'; });
  document.addEventListener('mouseenter', () => { dot.style.opacity = '1'; ring.style.opacity = '1'; });
})();

/* ── NAVBAR ─────────────────────────────────────────────────── */
(function initNavbar() {
  const nav    = document.getElementById('navbar');
  const toggle = document.getElementById('nav-toggle');
  const links  = document.getElementById('nav-links');

  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 40);
  }, { passive: true });

  toggle.addEventListener('click', () => {
    toggle.classList.toggle('open');
    links.classList.toggle('open');
  });

  // Close on link click
  links.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      toggle.classList.remove('open');
      links.classList.remove('open');
    });
  });
})();

/* ── SMOOTH SCROLL ──────────────────────────────────────────── */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const offset = 80;
    const top = target.getBoundingClientRect().top + window.scrollY - offset;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});

/* ── SCROLL REVEAL ──────────────────────────────────────────── */
(function initReveal() {
  const els = document.querySelectorAll('.reveal');
  if (!els.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  els.forEach(el => observer.observe(el));
})();

/* ── SKILL BARS ─────────────────────────────────────────────── */
(function initBars() {
  const sections = document.querySelectorAll('.bars');
  if (!sections.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.querySelectorAll('.bar-fill').forEach((fill, i) => {
        setTimeout(() => {
          fill.style.width = fill.dataset.w + '%';
          fill.classList.add('animated');
        }, i * 120);
      });
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.3 });

  sections.forEach(s => observer.observe(s));
})();

/* ── STAT COUNTER ───────────────────────────────────────────── */
(function initCounters() {
  const counters = document.querySelectorAll('[data-count]');
  if (!counters.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el     = entry.target;
      const target = parseInt(el.dataset.count, 10);
      const suffix = el.dataset.suffix || '';
      const dur    = 1400;
      const start  = performance.now();

      function step(now) {
        const t   = Math.min((now - start) / dur, 1);
        const val = Math.round(easeOut(t) * target);
        el.textContent = val + suffix;
        if (t < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
      observer.unobserve(el);
    });
  }, { threshold: 0.5 });

  counters.forEach(el => observer.observe(el));

  function easeOut(t) { return 1 - Math.pow(1 - t, 3); }
})();

/* ── ACTIVE NAV LINK (on scroll) ────────────────────────────── */
(function initActiveNav() {
  const sections = document.querySelectorAll('section[id]');
  const links    = document.querySelectorAll('.nav-links a[href^="#"]');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const id = entry.target.getAttribute('id');
      links.forEach(a => {
        a.style.color = a.getAttribute('href') === '#' + id
          ? 'var(--text)'
          : '';
      });
    });
  }, { threshold: 0.4 });

  sections.forEach(s => observer.observe(s));
})();

/* ── PARALLAX GLOW ──────────────────────────────────────────── */
(function initParallax() {
  const glows = document.querySelectorAll('.glow');
  if (!glows.length || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  let lastY = 0;
  window.addEventListener('scroll', () => {
    const y = window.scrollY;
    if (Math.abs(y - lastY) < 2) return;
    lastY = y;
    glows.forEach((g, i) => {
      const speed = i % 2 === 0 ? 0.06 : -0.04;
      g.style.transform = `translateY(${y * speed}px)`;
    });
  }, { passive: true });
})();

/* ── TILT CARDS ─────────────────────────────────────────────── */
(function initTilt() {
  const cards = document.querySelectorAll('.proj-featured, .proj-small, .stat-card');
  if (window.matchMedia('(hover: none)').matches) return;

  cards.forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const cx = (e.clientX - rect.left) / rect.width  - 0.5;
      const cy = (e.clientY - rect.top)  / rect.height - 0.5;
      card.style.transform = `
        perspective(800px)
        rotateX(${-cy * 6}deg)
        rotateY(${cx * 6}deg)
        translateY(-6px)
      `;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });
})();

/* ── MAGNETIC BUTTONS ───────────────────────────────────────── */
(function initMagnetic() {
  const btns = document.querySelectorAll('.btn-fill');
  if (window.matchMedia('(hover: none)').matches) return;

  btns.forEach(btn => {
    btn.addEventListener('mousemove', e => {
      const rect = btn.getBoundingClientRect();
      const cx = e.clientX - rect.left - rect.width  / 2;
      const cy = e.clientY - rect.top  - rect.height / 2;
      btn.style.transform = `translate(${cx * 0.2}px, ${cy * 0.3}px) translateY(-3px)`;
    });
    btn.addEventListener('mouseleave', () => { btn.style.transform = ''; });
  });
})();

/* ── TYPED HERO SUBTITLE ────────────────────────────────────── */
(function initTyped() {
  const el = document.getElementById('hero-typed');
  if (!el) return;

  const words  = ['Dev Full Stack', 'DevOps Engineer', 'Tech Lead', 'Backend Dev'];
  let   wi     = 0;
  let   ci     = 0;
  let   del    = false;

  function tick() {
    const word = words[wi];
    if (!del) {
      el.textContent = word.slice(0, ++ci);
      if (ci === word.length) { del = true; setTimeout(tick, 1800); return; }
    } else {
      el.textContent = word.slice(0, --ci);
      if (ci === 0) { del = false; wi = (wi + 1) % words.length; }
    }
    setTimeout(tick, del ? 60 : 90);
  }
  setTimeout(tick, 1800);
})();

/* ── HORIZONTAL MARQUEE (auto-scroll) ──────────────────────── */
(function initMarquee() {
  const track = document.querySelector('.marquee-track');
  if (!track) return;
  let x = 0;
  const speed = 0.5;
  const w = track.scrollWidth / 2;

  function animate() {
    x -= speed;
    if (Math.abs(x) >= w) x = 0;
    track.style.transform = `translateX(${x}px)`;
    requestAnimationFrame(animate);
  }
  animate();
})();
